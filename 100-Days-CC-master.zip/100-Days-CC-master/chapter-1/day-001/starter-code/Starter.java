public class Starter {
     
     public static void main(String[] args) {
          
          // your code goes here...
          
     }
     
}