public class Solution {
     public static void main(String[] args) {
          verse1();
          System.out.println();
          verse2();
          System.out.println();
          verse3();
          System.out.println();
          verse4();
          System.out.println();
          verse5();
          System.out.println();
          verse6();
          System.out.println();
          verse7();
          System.out.println();
          verse8();
          System.out.println();
          verse9();
          System.out.println();
          verse10();
          System.out.println();
          verse11();
          System.out.println();
          verse12();
     }
     
     public static void verse1() {
          System.out.println("On the first day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("A partridge in a pear tree.");
     }
          
     public static void verse2() {
          System.out.println("On the second day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse3() {
          System.out.println("On the third day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse4() {
          System.out.println("On the fourth day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse5() {
          System.out.println("On the fifth day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Five golden rings,");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse6() {
          System.out.println("On the sixth day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Six geese a-laying,");
          System.out.println("Five golden rings,");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse7() {
          System.out.println("On the seventh day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Seven swans a-swimming,");
          System.out.println("Six geese a-laying,");
          System.out.println("Five golden rings,");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse8() {
          System.out.println("On the eighth day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Eight maids a-milking,");
          System.out.println("Seven swans a-swimming,");
          System.out.println("Six geese a-laying,");
          System.out.println("Five golden rings,");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse9() {
          System.out.println("On the ninth day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Nine ladies dancing,");
          System.out.println("Eight maids a-milking,");
          System.out.println("Seven swans a-swimming,");
          System.out.println("Six geese a-laying,");
          System.out.println("Five golden rings,");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse10() {
          System.out.println("On the tenth day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Ten lords a-leaping,");
          System.out.println("Nine ladies dancing,");
          System.out.println("Eight maids a-milking,");
          System.out.println("Seven swans a-swimming,");
          System.out.println("Six geese a-laying,");
          System.out.println("Five golden rings,");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse11() {
          System.out.println("On the eleventh day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Eleven pipers piping,");
          System.out.println("Ten lords a-leaping,");
          System.out.println("Nine ladies dancing,");
          System.out.println("Eight maids a-milking,");
          System.out.println("Seven swans a-swimming,");
          System.out.println("Six geese a-laying,");
          System.out.println("Five golden rings,");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
          
     public static void verse12() {
          System.out.println("On the twelfth day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Twelve drummers drumming,");
          System.out.println("Eleven pipers piping,");
          System.out.println("Ten lords a-leaping,");
          System.out.println("Nine ladies dancing,");
          System.out.println("Eight maids a-milking,");
          System.out.println("Seven swans a-swimming,");
          System.out.println("Six geese a-laying,");
          System.out.println("Five golden rings,");
          System.out.println("Four calling birds,");
          System.out.println("Three French hens,");
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
}