public class Solution {

     public static void main(String[] args) {
          verse1();
          System.out.println();
          verse2();
          System.out.println();
          verse3();
          System.out.println();
          verse4();
          System.out.println();
          verse5();
          System.out.println();
          verse6();
          System.out.println();
          verse7();
          System.out.println();
          verse8();
          System.out.println();
          verse9();
          System.out.println();
          verse10();
          System.out.println();
          verse11();
          System.out.println();
          verse12();
     }
     
     public static void verse1() {
          System.out.println("On the first day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("A partridge in a pear tree.");
     }
     
     public static void verse2() {
          System.out.println("On the second day of Christmas,");
          System.out.println("my true love sent to me");
          verse2End();
     }
     
     public static void verse2End() {
          System.out.println("Two turtle doves,");
          System.out.println("And a partridge in a pear tree.");
     }
     
     public static void verse3() {
          System.out.println("On the third day of Christmas,");
          System.out.println("my true love sent to me");
          verse3End();
     }
     
     public static void verse3End() {
          System.out.println("Three French hens,");
          verse2End();
     }
     
     public static void verse4() {
          System.out.println("On the fourth day of Christmas,");
          System.out.println("my true love sent to me");
          verse4End();
     }
     
     public static void verse4End() {
          System.out.println("Four calling birds,");
          verse3End();
     }
     
     public static void verse5() {
          System.out.println("On the fifth day of Christmas,");
          System.out.println("my true love sent to me");
          verse5End();
     }
     
     public static void verse5End() {
          System.out.println("Five golden rings,");
          verse4End();
     }
     
     public static void verse6() {
          System.out.println("On the sixth day of Christmas,");
          System.out.println("my true love sent to me");
          verse6End();
     }
     
     public static void verse6End() {
          System.out.println("Six geese a-laying,");
          verse5End();
     }
     
     public static void verse7() {
          System.out.println("On the seventh day of Christmas,");
          System.out.println("my true love sent to me");
          verse7End();
     }
     
     public static void verse7End() {
          System.out.println("Seven swans a-swimming,");
          verse6End();
     }
     
     public static void verse8() {
          System.out.println("On the eighth day of Christmas,");
          System.out.println("my true love sent to me");
          verse8End();
     }
     
     public static void verse8End() {
          System.out.println("Eight maids a-milking,");
          verse7End();
     }
     
     public static void verse9() {
          System.out.println("On the ninth day of Christmas,");
          System.out.println("my true love sent to me");
          verse9End();
     }
     
     public static void verse9End() {
          System.out.println("Nine ladies dancing,");
          verse8End();
     }
     
     public static void verse10() {
          System.out.println("On the tenth day of Christmas,");
          System.out.println("my true love sent to me");
          verse10End();
     }
     
     public static void verse10End() {
          System.out.println("Ten lords a-leaping,");
          verse9End();
     }
     
     public static void verse11() {
          System.out.println("On the eleventh day of Christmas,");
          System.out.println("my true love sent to me");
          verse11End();
     }
     
     public static void verse11End() {
          System.out.println("Eleven pipers piping,");
          verse10End();
     }
     
     public static void verse12() {
          System.out.println("On the twelfth day of Christmas,");
          System.out.println("my true love sent to me");
          System.out.println("Twelve drummers drumming,");
          verse11End();
     }
}