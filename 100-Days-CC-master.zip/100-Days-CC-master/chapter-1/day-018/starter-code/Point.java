public class Point {
	
	private int x;
	private int y;
	
	public Point(int x, int y) {
		
	}
	
	public Point() {
		
	}
	
	public void translate(int dx, int dy) {
		
	}
	
	public double distanceFromOrigin() {
		
	}
	
	public String toString() {
		
	}
	
	public double distanceFrom(Point otherPoint) {
		
	}
	
	public int getX() {
		
	}
	
	public int getY() {
		
	}
	
	public void setLocation(int x, int y) {
		
	}
}