public class Starter {
     
     public static void main(String[] args) {
          
          Scanner console = new Scanner(System.in);
          Random randy = new Random();
          int guesses = game(console, randy);

          System.out.println("It took you " + guesses + " guess(es)");
          
     }
     
     public static int game(Scanner console, Random randy) {
          
          // your code goes here...
          
     }
     
}
