public class Starter {
     
     public static void main(String[] args) {
          section1();
          section2();
          section3();
          section4();
          section5();
     }
     
     public static void section1() {
          
     }
     
     public static void section2() {
          
     }
     
     public static void section3() {
          
     }
     
     public static void section4() {
          
     }
     
     public static void section5() {
          
     }
}
