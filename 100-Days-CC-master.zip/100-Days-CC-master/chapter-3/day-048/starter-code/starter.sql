/* Navigate to https://webster.cs.washington.edu/cse154/query/  to test your SQL queries */
